# Question Bank for Source-Grounded AI Exploration

Upload this pack into NotebookLM, ChatGPT, Claude, Gemini, or another source-grounded workspace and try questions such as:

1. Explain four-wall visibility and network visibility using a pharmaceutical virtual manufacturer.
2. Why can an ERP be accurate while the supply chain is already off plan?
3. Walk the synthetic scenario through physical, information, and financial flows.
4. Which network events should be direct evidence rather than model inference?
5. Design a data model connecting forecast, purchase order, batch, shipment, inventory, and partner location.
6. What could EPCIS contribute to network visibility, and what would it not solve by itself?
7. Build a visibility maturity assessment for a CMO-dependent manufacturer.
8. What are the biggest differences between Level 2 partner status and Level 3 cross-partner process visibility?
9. How would you identify stale data in a network-visibility architecture?
10. What permission model would be needed if several CMOs serve different products or markets?
11. Where could an AI agent coordinate work without changing an authoritative source system?
12. Which decisions should remain human-approved in a regulated operating model?
13. What questions should an executive ask when a vendor claims “end-to-end visibility”?
14. How can a company make blind spots explicit instead of presenting an incomplete dashboard as complete?
15. Design a 90-day pilot for improving one network visibility problem without attempting to digitize the entire supply chain.

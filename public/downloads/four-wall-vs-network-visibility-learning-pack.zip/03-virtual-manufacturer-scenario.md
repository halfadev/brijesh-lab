# Synthetic Scenario: A Virtual Manufacturer Learns About a Delay Too Late

A fictional pharmaceutical company, **Northstar Therapeutics**, owns a product but outsources manufacturing and logistics.

Its network includes:

- a raw-material supplier;
- a CMO;
- an external testing laboratory;
- a carrier;
- a 3PL;
- a specialty distributor.

## Monday
Northstar's ERP shows an open purchase order with the expected date unchanged. Its planning system still assumes the original production completion date.

At the CMO, however, a critical material has arrived late.

## Tuesday
The CMO moves the batch to a later production slot. The new date is discussed in email and updated in the CMO's local schedule.

Northstar's planning system is not updated.

## Wednesday
The external lab still holds the original testing window. The 3PL still expects inbound inventory on the original schedule.

Every company's local system remains internally consistent.

## Friday
Northstar finally receives a manual status update and changes its expected date.

The ERP is now accurate.

But the important insight is that the ERP did not discover the risk. It recorded the risk after the cross-company process had already changed.

## Questions

1. Which facts existed on Monday but were not visible to Northstar?
2. Which event should have crossed the company boundary first?
3. What identifiers would connect the CMO schedule, purchase order, batch, lab work, shipment, and 3PL receipt?
4. Which status should be direct evidence and which could be inferred?
5. At what point could an AI agent safely help?
6. What should happen if the CMO never supplies the milestone?

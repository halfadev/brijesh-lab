# Four-Wall Visibility vs Network Visibility: Learning Pack

This pack accompanies the explainer **Four-Wall Visibility vs Network Visibility**.

It is designed to help you move from reading the model to applying it.

## Suggested workflow

1. Read `01-four-wall-vs-network-visibility.md`.
2. Use `02-visibility-maturity-model.md` to score a process or network.
3. Work through the synthetic scenario in `03-virtual-manufacturer-scenario.md`.
4. Use `04-network-visibility-diagnostic.md` to identify the real visibility gap.
5. Ask the prompts in `05-question-bank.md` in NotebookLM, ChatGPT, Claude, Gemini, or another source-grounded workspace.
6. Use `06-sources.md` for authoritative public references.

## Important note

This pack is educational. The scenarios are synthetic and generalized. It contains no customer-specific or confidential operating information.

# Visibility Maturity Model

## Level 1: Inside the wall
You can see your own orders, inventory, milestones, quality state, and transactions.

**Test:** Can internal teams reconstruct the current state without emailing one another?

## Level 2: Partner status
You receive selected external events or updates from individual partners.

**Test:** Are critical external milestones available digitally and on time?

## Level 3: Cross-partner process
You can connect evidence from multiple partners around one process.

**Test:** Can forecast, CMO commitment, production, quality, shipment, and receipt be viewed as one chain of evidence?

## Level 4: Network context
Events can be interpreted against inventory, demand, market, product, and customer context.

**Test:** When one milestone slips, can you identify what might be affected?

## Level 5: Coordinated action
The network evidence can drive an owned, governed next step.

**Test:** Does an exception reliably create the right action, owner, escalation, or decision?

## Scoring note
A network can be Level 4 for one process and Level 1 for another. Do not score the enterprise as one number. Score specific decisions and workflows.

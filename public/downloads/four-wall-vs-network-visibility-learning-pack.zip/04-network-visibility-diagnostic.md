# Network Visibility Diagnostic

Use these questions against one specific process such as external manufacturing, inbound logistics, product release, replenishment, or recall.

## Boundary
- Where does our current visibility stop?
- Which organizations perform critical steps outside our direct control?
- Which external milestones matter to the outcome?

## Evidence
- Which partner generates each critical fact?
- Is the evidence direct, inferred, or manually reported?
- How quickly after the real-world event does the evidence arrive?
- Can we retrieve the original evidence behind a status?

## Identity
- What identifiers survive across the handoff?
- Can product, material, batch, PO, shipment, location, and partner records be connected?
- Where do teams currently match records manually?

## Meaning
- Do all partners mean the same thing by “complete,” “released,” “shipped,” or “received”?
- Which business milestones need explicit definitions?

## Governance
- Who is allowed to see which data?
- Which events should be shared bilaterally versus across a wider network?
- Who owns resolution when evidence is missing or conflicting?

## Action
- What decision should each visibility signal enable?
- What is the useful decision window?
- Is the next action automated, recommended, or human-approved?
- Does the workflow close the loop back to the partners involved?

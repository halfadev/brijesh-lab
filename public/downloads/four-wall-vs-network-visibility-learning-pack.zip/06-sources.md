# Public Sources and Further Reading

## FDA

**Contract Manufacturing Arrangements for Drugs: Quality Agreements Guidance for Industry** (2016)
https://www.fda.gov/regulatory-information/search-fda-guidance-documents/contract-manufacturing-arrangements-drugs-quality-agreements-guidance-industry

Why it matters: demonstrates that outsourced drug manufacturing requires explicit definition and communication of responsibilities across the owner and contract facility, including facilities/equipment, materials management, and traceability-related practices.

## GS1

**EPCIS & CBV**
https://www.gs1.org/standards/epcis

Why it matters: EPCIS is designed for sharing visibility-event information both within organizations and across trading partners.

**EPCIS and CBV Implementation Guideline**
https://ref.gs1.org/guidelines/epcis-cbv/2.0.0/

Why it matters: distinguishes master data, transaction data, and visibility-event data, and explains cross-enterprise visibility concepts.

**GS1 Global Traceability Standard**
https://www.gs1.org/standards/gs1-global-traceability-standard/current-standard

Why it matters: frames traceability and visibility across supply-chain processes and trading partners.

## Editorial note

These sources support the regulatory/standards background. The article's maturity model and four-wall-versus-network framing are editorial synthesis intended as teaching frameworks, not official terminology from FDA or GS1.

import type { Metadata } from "next";
import Link from "next/link";
import { getCourses } from "@/lib/content";
import { pageMetadata } from "@/lib/metadata";
export const metadata: Metadata = pageMetadata({ title: "Learn", description: "Structured learning paths for understanding complex systems in life sciences.", path: "/learn" });
export default function LearnPage() { const courses = getCourses(); return <main className="editorial-main"><p className="eyebrow">Learn</p><h1>Learn</h1><p className="lead">Some ideas make more sense in sequence.</p><p className="editorial-copy">These learning paths build from first principles, then progressively connect business models, operations, data, technology, and decision-making.</p>{courses.map((course) => <section className="learning-path" key={course.slug}><p className="course-meta">{course.status === "draft" ? "Draft preview" : "Available course"}</p><h2><Link href={course.route}>{course.title}</Link></h2><p>{course.dek}</p><Link className="editorial-link" href={course.route}>View the course →</Link></section>)}</main>; }

import { MDXRemote } from "next-mdx-remote/rsc";
import type { Entry } from "@/lib/content";
import { ArticleBody, Callout, Caption, ImageBlock, InfographicBlock, KeyConcept, Sources, VideoEmbed } from "@/components/ui/ArticlePrimitives";

const components = { Callout, Caption, ImageBlock, InfographicBlock, KeyConcept, Sources, VideoEmbed };

export async function ContentRenderer({ entry }: { entry: Entry }) {
  return <ArticleBody><MDXRemote source={entry.source} components={components} /></ArticleBody>;
}

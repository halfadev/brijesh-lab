import Link from "next/link";

export function Header() {
  return (
    <header className="site-header">
      <Link className="brand" href="/">
        Brijesh Ramakrishnan
      </Link>
      <nav className="nav site-nav" aria-label="Primary navigation">
        <Link href="/writing">Writing</Link>
        <Link href="/videos">Videos</Link>
        <Link href="/learn">Learn</Link>
        <Link href="/lab">Lab</Link>
      </nav>
    </header>
  );
}

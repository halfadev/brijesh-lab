import fs from "node:fs";
import path from "node:path";
import matter from "gray-matter";
import { marked } from "marked";

export type ContentSection = "writing" | "videos" | "learn" | "lab";
export type ContentType = "article" | "video" | "course" | "lesson" | "lab";
export type ContentStatus = "draft" | "published";

export type EntryFrontmatter = {
  title: string; slug: string; type: ContentType; dek: string; date: string;
  status: ContentStatus; tags: string[]; featured: boolean; category?: string;
  course?: string; module?: string; youtubeId?: string; duration?: string;
  previous?: string; next?: string; objective?: string;
};
export type EntrySummary = EntryFrontmatter & { section: ContentSection; route: string; draft: boolean };
export type Entry = EntrySummary & { source: string; html: string };

const contentDir = path.join(process.cwd(), "content");
const extensions = new Set([".md", ".mdx"]);

function normalizeDate(value: unknown): string {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return typeof value === "string" ? value : "";
}
function normalizeString(value: unknown): string | undefined {
  if (typeof value === "number") return String(value).padStart(2, "0");
  return typeof value === "string" && value.trim() ? value.trim() : undefined;
}
function walk(directory: string): string[] {
  if (!fs.existsSync(directory)) return [];
  return fs.readdirSync(directory, { withFileTypes: true }).flatMap((item) => {
    const filePath = path.join(directory, item.name);
    if (item.isDirectory()) return walk(filePath);
    return extensions.has(path.extname(item.name)) ? [filePath] : [];
  });
}
function routeFor(section: ContentSection, slug: string, course?: string, type?: ContentType) {
  if (type === "course") return `/learn/${slug}`;
  if (section === "learn") return `/learn/${course}/${slug}`;
  return `/${section}/${slug}`;
}
function readFile(section: ContentSection, filePath: string): Entry {
  const raw = fs.readFileSync(filePath, "utf8");
  const { data, content } = matter(raw);
  const fallbackSlug = path.basename(filePath, path.extname(filePath));
  const courseFromPath = section === "learn"
    ? path.relative(path.join(contentDir, "learn"), path.dirname(filePath)).split(path.sep)[0]
    : undefined;
  const type = (data.type ?? (section === "videos" ? "video" : section === "lab" ? "lab" : section === "learn" ? "lesson" : "article")) as ContentType;
  const slug = normalizeString(data.slug) ?? (type === "course" ? courseFromPath : fallbackSlug) ?? fallbackSlug;
  const status: ContentStatus = data.status === "draft" || data.draft === true ? "draft" : "published";
  const course = normalizeString(data.course) ?? courseFromPath;
  if (!data.title || !slug || !type) throw new Error(`Missing required content frontmatter in ${path.relative(process.cwd(), filePath)}`);
  return {
    section, slug, type, title: String(data.title), dek: String(data.dek ?? ""),
    date: normalizeDate(data.date), status,
    tags: Array.isArray(data.tags) ? data.tags.map(String) : [], featured: Boolean(data.featured),
    category: normalizeString(data.category), course, module: normalizeString(data.module),
    youtubeId: normalizeString(data.youtubeId), duration: normalizeString(data.duration),
    previous: normalizeString(data.previous), next: normalizeString(data.next),
    objective: normalizeString(data.objective), route: routeFor(section, slug, course, type),
    draft: status === "draft", source: content,
    html: marked.parse(content, { async: false }) as string,
  };
}
export function getAllContent(): Entry[] {
  const sections: ContentSection[] = ["writing", "videos", "learn", "lab"];
  return sections.flatMap((section) => walk(path.join(contentDir, section)).map((filePath) => readFile(section, filePath)));
}
function newestFirst(a: EntrySummary, b: EntrySummary) { return a.date < b.date ? 1 : a.date > b.date ? -1 : 0; }
export function getEntries(section: ContentSection, includeDrafts = process.env.NODE_ENV !== "production"): EntrySummary[] {
  return getAllContent().filter((entry) => entry.section === section && entry.type !== "course")
    .filter((entry) => includeDrafts || entry.status === "published").sort(newestFirst);
}
export function getPublishedEntries(): EntrySummary[] {
  return getAllContent().filter((entry) => entry.type !== "course" && entry.status === "published").sort(newestFirst);
}
export function getFeaturedEntries(limit = 4): EntrySummary[] {
  return getPublishedEntries().filter((entry) => entry.featured).slice(0, limit);
}
export function getEntry(section: ContentSection, slug: string, course?: string): Entry | null {
  const entry = getAllContent().find((item) => item.section === section && item.slug === slug && (!course || item.course === course));
  if (!entry || (process.env.NODE_ENV === "production" && entry.status !== "published")) return null;
  return entry;
}
export function getCourse(slug: string): Entry | null {
  const entry = getAllContent().find((item) => item.type === "course" && item.slug === slug);
  if (!entry || (process.env.NODE_ENV === "production" && entry.status !== "published")) return null;
  return entry;
}
export function getCourses(includeDrafts = process.env.NODE_ENV !== "production"): EntrySummary[] {
  return getAllContent().filter((entry) => entry.type === "course" && (includeDrafts || entry.status === "published")).sort(newestFirst);
}
export function getCourseLessons(course: string, includeDrafts = process.env.NODE_ENV !== "production"): EntrySummary[] {
  return getAllContent().filter((entry) => entry.type === "lesson" && entry.course === course)
    .filter((entry) => includeDrafts || entry.status === "published")
    .sort((a, b) => (a.module ?? "").localeCompare(b.module ?? ""));
}
export function getEntrySlugs(section: ContentSection): string[] { return getEntries(section, false).map((entry) => entry.slug); }
export function formatDate(isoDate: string): string {
  if (!isoDate) return "";
  const [year, month, day] = isoDate.split("-").map(Number);
  if (!year || !month || !day) return isoDate;
  return new Date(Date.UTC(year, month - 1, day)).toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric", timeZone: "UTC" });
}
export function formatMonthYear(isoDate: string): string {
  if (!isoDate) return "";
  const [year, month] = isoDate.split("-").map(Number);
  if (!year || !month) return isoDate;
  return new Date(Date.UTC(year, month - 1, 1)).toLocaleDateString("en-US", { year: "numeric", month: "long", timeZone: "UTC" });
}
export function getNow() {
  const raw = fs.readFileSync(path.join(contentDir, "now.md"), "utf8");
  const { data, content } = matter(raw);
  return { updated: normalizeDate(data.updated), html: marked.parse(content, { async: false }) as string };
}
